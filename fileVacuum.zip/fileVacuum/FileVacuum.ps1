
# ============================================================
# FILE VACUUM - FULL SYSTEM FILE FINDER TUI
# ============================================================
# Requirements:
#   fd.exe
#   fzf.exe
#
# Features:
#   - Dynamically discovers all mounted filesystem drives
#   - Searches hidden and ignored files
#   - Uses fd + fzf for interactive selection
#   - Copy path / Copy file / Open / Move / Delete
#   - Independent of current working directory
#
# Installation:
#   Dot-source this file from your PowerShell profile.
#
# Usage:
#   filevacuum
#   filevacuum FileVacuum.ps1
# ============================================================


function filevacuum {

    [CmdletBinding()]
    param(
        [Parameter(Position = 0)]
        [string]$Query
    )

    # --------------------------------------------------------
    # 1. CHECK DEPENDENCIES
    # --------------------------------------------------------

    $FD  = Get-Command "fd.exe"  -ErrorAction SilentlyContinue
    $FZF = Get-Command "fzf.exe" -ErrorAction SilentlyContinue

    if (-not $FD) {
        Write-Host "`n[ERROR] fd.exe was not found." -ForegroundColor Red
        return
    }

    if (-not $FZF) {
        Write-Host "`n[ERROR] fzf.exe was not found." -ForegroundColor Red
        return
    }

    # --------------------------------------------------------
    # 2. GET SEARCH QUERY
    # --------------------------------------------------------

    if ([string]::IsNullOrWhiteSpace($Query)) {

        Write-Host ""
        Write-Host "========================================" -ForegroundColor Cyan
        Write-Host "          FILE VACUUM TUI" -ForegroundColor Cyan
        Write-Host "========================================" -ForegroundColor Cyan

        $Query = Read-Host "Enter file name or search term"

        if ([string]::IsNullOrWhiteSpace($Query)) {
            Write-Host "[CANCELLED] No search term provided." -ForegroundColor Yellow
            return
        }
    }

    # --------------------------------------------------------
    # 3. DISCOVER ALL AVAILABLE DRIVES
    # --------------------------------------------------------

    try {

        $Drives = @(
            [System.IO.DriveInfo]::GetDrives() |
            Where-Object {
                $_.IsReady -and
                $_.DriveType -in @(
                    [System.IO.DriveType]::Fixed,
                    [System.IO.DriveType]::Removable,
                    [System.IO.DriveType]::Network
                )
            } |
            ForEach-Object {
                $_.RootDirectory.FullName
            }
        )

    }
    catch {

        Write-Host "[ERROR] Unable to discover drives." -ForegroundColor Red
        return

    }

    if ($Drives.Count -eq 0) {

        Write-Host "[ERROR] No accessible drives found." -ForegroundColor Red
        return

    }

    # --------------------------------------------------------
    # 4. DISPLAY DRIVE INFORMATION
    # --------------------------------------------------------

    Write-Host ""
    Write-Host "[SCAN] Searching the following drives:" -ForegroundColor Cyan

    foreach ($Drive in $Drives) {
        Write-Host "  + $Drive" -ForegroundColor Green
    }

    Write-Host ""
    Write-Host "[SCAN] Launching fd + fzf..." -ForegroundColor Yellow

    # --------------------------------------------------------
    # 5. PREPARE FD ARGUMENTS
    # --------------------------------------------------------

    $FdArguments = @(
        "--hidden"
        "--no-ignore"
        "--type"
        "f"
        "--absolute-path"
        "--color"
        "never"
        "."
    ) + $Drives

    # --------------------------------------------------------
    # 6. PREPARE FZF ARGUMENTS
    # --------------------------------------------------------

    $FzfArguments = @(
        "--height=90%"
        "--layout=reverse"
        "--border"
        "--info=inline"
        "--no-multi"
        "--prompt=FileVacuum> "
        "--header=ENTER: Select | CTRL+C: Cancel | Type to filter"
        "--query=$Query"
    )

    # --------------------------------------------------------
    # 7. EXECUTE FULL SYSTEM SEARCH
    # --------------------------------------------------------

    $SelectedPath = $null

    try {

        $SelectedPath = @(
            & $FD.Source @FdArguments 2>$null |
            & $FZF.Source @FzfArguments
        ) | Select-Object -First 1

    }
    catch {

        Write-Host ""
        Write-Host "[ERROR] Search could not be completed." -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor DarkRed
        return

    }

    # --------------------------------------------------------
    # 8. HANDLE CANCELLED SEARCH
    # --------------------------------------------------------

    if (
        [string]::IsNullOrWhiteSpace([string]$SelectedPath) -or
        -not (Test-Path -LiteralPath $SelectedPath -PathType Leaf)
    ) {

        Write-Host ""
        Write-Host "[INFO] No file selected." -ForegroundColor Yellow
        return

    }

    $SelectedPath = (Get-Item -LiteralPath $SelectedPath).FullName

    # --------------------------------------------------------
    # 9. FILE ACTION MENU
    # --------------------------------------------------------

    while ($true) {

        Clear-Host

        $FileInfo = Get-Item -LiteralPath $SelectedPath

        Write-Host ""
        Write-Host "============================================" -ForegroundColor Cyan
        Write-Host "             FILE VACUUM TUI" -ForegroundColor Cyan
        Write-Host "============================================" -ForegroundColor Cyan

        Write-Host ""
        Write-Host "SELECTED FILE" -ForegroundColor Yellow

        Write-Host $SelectedPath -ForegroundColor Green

        Write-Host ""
        Write-Host "FILE INFORMATION" -ForegroundColor Yellow

        Write-Host "Name       : $($FileInfo.Name)"
        Write-Host "Extension  : $($FileInfo.Extension)"
        Write-Host "Size       : $([math]::Round($FileInfo.Length / 1KB, 2)) KB"
        Write-Host "Directory  : $($FileInfo.DirectoryName)"
        Write-Host "Modified   : $($FileInfo.LastWriteTime)"

        Write-Host ""
        Write-Host "============================================" -ForegroundColor DarkCyan
        Write-Host "              ACTION MENU" -ForegroundColor Cyan
        Write-Host "============================================" -ForegroundColor DarkCyan

        Write-Host ""
        Write-Host " [1] Copy full file path"
        Write-Host " [2] Open file"
        Write-Host " [3] Copy file (paste using CTRL+V)"
        Write-Host " [4] Copy file to another folder"
        Write-Host " [5] Move file to another folder"
        Write-Host " [6] Reveal in File Explorer"
        Write-Host " [7] Open terminal in file location"
        Write-Host " [8] File properties"
        Write-Host " [9] Delete file"
        Write-Host ""
        Write-Host " [R] Search again"
        Write-Host " [Q] Quit"
        Write-Host ""

        $Action = Read-Host "Select an action"

        switch ($Action.ToUpperInvariant()) {

            # ------------------------------------------------
            # 1. COPY FULL FILE PATH
            # ------------------------------------------------

            "1" {

                Set-Clipboard -Value $SelectedPath

                Write-Host "`n[OK] Full file path copied." -ForegroundColor Green

                Write-Host $SelectedPath -ForegroundColor Gray

                Pause
            }

            # ------------------------------------------------
            # 2. OPEN FILE
            # ------------------------------------------------

            "2" {

                Start-Process -FilePath $SelectedPath

                Write-Host "`n[OK] Opening file..." -ForegroundColor Green

                Start-Sleep -Seconds 1
            }

            # ------------------------------------------------
            # 3. COPY FILE TO WINDOWS CLIPBOARD
            # ------------------------------------------------

            "3" {

                try {

                    Set-Clipboard -Path @($SelectedPath)

                    Write-Host ""
                    Write-Host "[OK] File copied to Windows clipboard." -ForegroundColor Green
                    Write-Host "Use CTRL+V to paste the actual file." -ForegroundColor Cyan

                }
                catch {

                    Write-Host ""
                    Write-Host "[ERROR] Unable to copy file to clipboard." -ForegroundColor Red
                    Write-Host $_.Exception.Message

                }

                Pause
            }

            # ------------------------------------------------
            # 4. COPY FILE TO ANOTHER FOLDER
            # ------------------------------------------------

            "4" {

                $Destination = Read-Host "`nEnter destination folder"

                if (Test-Path -LiteralPath $Destination -PathType Container) {

                    try {

                        Copy-Item -LiteralPath $SelectedPath -Destination $Destination -ErrorAction Stop

                        Write-Host "`n[OK] File copied successfully." -ForegroundColor Green

                    }
                    catch {

                        Write-Host "`n[ERROR] Copy failed." -ForegroundColor Red
                        Write-Host $_.Exception.Message

                    }

                }
                else {

                    Write-Host "`n[ERROR] Destination folder does not exist." -ForegroundColor Red

                }

                Pause
            }

            # ------------------------------------------------
            # 5. MOVE FILE
            # ------------------------------------------------

            "5" {

                $Destination = Read-Host "`nEnter destination folder"

                if (Test-Path -LiteralPath $Destination -PathType Container) {

                    try {

                        Move-Item -LiteralPath $SelectedPath -Destination $Destination -ErrorAction Stop

                        Write-Host "`n[OK] File moved successfully." -ForegroundColor Green

                        return

                    }
                    catch {

                        Write-Host "`n[ERROR] Move failed." -ForegroundColor Red
                        Write-Host $_.Exception.Message

                    }

                }
                else {

                    Write-Host "`n[ERROR] Destination folder does not exist." -ForegroundColor Red

                }

                Pause
            }

            # ------------------------------------------------
            # 6. REVEAL IN FILE EXPLORER
            # ------------------------------------------------

            "6" {

                Start-Process -FilePath "explorer.exe" -ArgumentList "/select,`"$SelectedPath`""

                Start-Sleep -Seconds 1
            }

            # ------------------------------------------------
            # 7. OPEN TERMINAL IN FILE LOCATION
            # ------------------------------------------------

            "7" {

                $Directory = Split-Path -Parent $SelectedPath

                if (Get-Command "wt.exe" -ErrorAction SilentlyContinue) {

                    Start-Process -FilePath "wt.exe" -ArgumentList @(
                        "-d"
                        $Directory
                    )

                }
                else {

                    Start-Process -FilePath "powershell.exe" -WorkingDirectory $Directory

                }

                Start-Sleep -Seconds 1
            }

            # ------------------------------------------------
            # 8. FILE PROPERTIES
            # ------------------------------------------------

            "8" {

                Start-Process -FilePath "rundll32.exe" -ArgumentList @(
                    "shell32.dll,Control_RunDLL"
                    "appwiz.cpl"
                ) -ErrorAction SilentlyContinue

                # Open the selected file's actual properties dialog
                $Shell = New-Object -ComObject Shell.Application

                $Folder = $Shell.Namespace($FileInfo.DirectoryName)
                $Item = $Folder.ParseName($FileInfo.Name)

                if ($Item) {
                    $Item.InvokeVerb("properties")
                }

                Pause
            }

            # ------------------------------------------------
            # 9. DELETE FILE
            # ------------------------------------------------

            "9" {

                Write-Host ""
                Write-Host "WARNING: This will permanently delete the selected file." -ForegroundColor Red

                $Confirmation = Read-Host "Type DELETE to confirm"

                if ($Confirmation -ceq "DELETE") {

                    try {

                        Remove-Item -LiteralPath $SelectedPath -Force -ErrorAction Stop

                        Write-Host "`n[OK] File deleted." -ForegroundColor Green

                        return

                    }
                    catch {

                        Write-Host "`n[ERROR] Delete failed." -ForegroundColor Red
                        Write-Host $_.Exception.Message

                    }

                }
                else {

                    Write-Host "`n[INFO] Deletion cancelled." -ForegroundColor Yellow

                }

                Pause
            }

            # ------------------------------------------------
            # R. SEARCH AGAIN
            # ------------------------------------------------

            "R" {

                $NewQuery = Read-Host "`nEnter another file name"

                if (-not [string]::IsNullOrWhiteSpace($NewQuery)) {

                    filevacuum -Query $NewQuery

                    return

                }

            }

            # ------------------------------------------------
            # Q. QUIT
            # ------------------------------------------------

            "Q" {

                Clear-Host
                return

            }

            default {

                Write-Host "`n[INVALID] Please select a valid option." -ForegroundColor Red

                Start-Sleep -Milliseconds 900

            }

        }

    }

}


# ============================================================
# END OF FILE VACUUM
# ============================================================
