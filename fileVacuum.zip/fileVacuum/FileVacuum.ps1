
# ============================================================
# FILE VACUUM v2.2
# STRICT DRIVE / FOLDER SCOPED FILE FINDER
# ============================================================
#
# REQUIREMENTS:
#   fd.exe
#   fzf.exe
#
# PROFILE:
#   . "C:\.scripts\fileVacuum\FileVacuum.ps1"
#
# USAGE:
#   filevacuum
#   filevacuum config.json
#
# ============================================================


function filevacuum {

    [CmdletBinding()]
    param(
        [Parameter(Position = 0)]
        [string]$Query
    )

    # --------------------------------------------------------
    # 1. DEPENDENCIES
    # --------------------------------------------------------

    $FD = Get-Command fd.exe -ErrorAction SilentlyContinue
    $FZF = Get-Command fzf.exe -ErrorAction SilentlyContinue

    if (-not $FD -or -not $FZF) {
        Write-Host "[ERROR] fd.exe or fzf.exe is missing." -ForegroundColor Red
        return
    }

    # --------------------------------------------------------
    # 2. DISCOVER AVAILABLE DRIVES
    # --------------------------------------------------------

    $Drives = @(
        [System.IO.DriveInfo]::GetDrives() |
        Where-Object {
            $_.IsReady -and
            $_.DriveType -in @(
                [System.IO.DriveType]::Fixed,
                [System.IO.DriveType]::Removable,
                [System.IO.DriveType]::Network
            )
        } |
        ForEach-Object {
            $_.RootDirectory.FullName
        }
    )

    if (-not $Drives) {
        Write-Host "[ERROR] No accessible drives found." -ForegroundColor Red
        return
    }

    # --------------------------------------------------------
    # 3. MULTI-SELECT HELPER
    # --------------------------------------------------------

    function Select-FVItems {

        param(
            [string[]]$Items,
            [string]$Prompt
        )

        if (-not $Items) {
            return
        }

        $Arguments = @(
            "--multi"
            "--height=85%"
            "--layout=reverse"
            "--border"
            "--info=inline"
            "--prompt=$Prompt"
            "--header=TAB: Select | ENTER: Confirm | ESC: Cancel"
        )

        $Result = @(
            $Items | & $FZF.Source @Arguments
        )

        $ExitCode = $LASTEXITCODE

        if ($ExitCode -ne 0 -or -not $Result) {
            return
        }

        return $Result
    }

    # --------------------------------------------------------
    # 4. NORMAL WINDOWS FOLDER PATH INPUT
    # --------------------------------------------------------

    function Read-FVFolderPaths {

        $SelectedFolders = [System.Collections.Generic.List[string]]::new()

        Write-Host ""
        Write-Host "============================================" -ForegroundColor Cyan
        Write-Host "          ADD SEARCH FOLDERS" -ForegroundColor Cyan
        Write-Host "============================================" -ForegroundColor Cyan

        Write-Host ""
        Write-Host "Paste a complete Windows folder path." -ForegroundColor Yellow
        Write-Host "Spaces, &, parentheses and other normal path characters are supported." -ForegroundColor Gray
        Write-Host ""
        Write-Host "Press ENTER on an empty line when finished." -ForegroundColor DarkGray

        while ($true) {

            Write-Host ""

            $InputPath = Read-Host "Folder path"

            if ([string]::IsNullOrWhiteSpace($InputPath)) {
                break
            }

            # Allow paths pasted with surrounding quotes.

            $InputPath = $InputPath.Trim().Trim('"').Trim("'")

            try {

                if (-not (Test-Path -LiteralPath $InputPath -PathType Container)) {

                    Write-Host "[INVALID] Folder does not exist or is inaccessible." -ForegroundColor Red
                    continue

                }

                $ResolvedPath = (Get-Item -LiteralPath $InputPath -ErrorAction Stop).FullName

                if (-not $SelectedFolders.Contains($ResolvedPath)) {

                    $SelectedFolders.Add($ResolvedPath)

                    Write-Host "[ADDED] $ResolvedPath" -ForegroundColor Green

                }
                else {

                    Write-Host "[INFO] Folder already added." -ForegroundColor Yellow

                }

            }
            catch {

                Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red

            }

        }

        return $SelectedFolders.ToArray()
    }

    # --------------------------------------------------------
    # 5. SEARCH SCOPE SELECTOR
    # --------------------------------------------------------

    function Select-FVScope {

        while ($true) {

            Clear-Host

            Write-Host ""
            Write-Host "================================================" -ForegroundColor Cyan
            Write-Host "                  FILE VACUUM" -ForegroundColor Cyan
            Write-Host "================================================" -ForegroundColor Cyan

            Write-Host ""
            Write-Host "             SELECT SEARCH SCOPE" -ForegroundColor Yellow

            Write-Host ""
            Write-Host " [1] Entire machine"
            Write-Host " [2] Specific drives"
            Write-Host " [3] Specific folders"
            Write-Host " [4] Combine drives + folders"

            Write-Host ""
            Write-Host " [Q] Quit"

            Write-Host ""
            Write-Host "AVAILABLE DRIVES:" -ForegroundColor Cyan

            foreach ($Drive in $Drives) {
                Write-Host "  + $Drive" -ForegroundColor Green
            }

            Write-Host ""

            $Choice = Read-Host "Choose search scope"

            switch ($Choice.ToUpperInvariant()) {

                # --------------------------------------------
                # ENTIRE MACHINE
                # --------------------------------------------

                "1" {

                    return $Drives

                }

                # --------------------------------------------
                # SPECIFIC DRIVES
                # --------------------------------------------

                "2" {

                    Write-Host ""
                    Write-Host "[DRIVE SELECTION]" -ForegroundColor Cyan

                    $SelectedDrives = Select-FVItems `
                        -Items $Drives `
                        -Prompt "Select-Drives> "

                    if ($SelectedDrives) {
                        return $SelectedDrives
                    }

                }

                # --------------------------------------------
                # SPECIFIC FOLDERS
                # --------------------------------------------

                "3" {

                    $SelectedFolders = @(Read-FVFolderPaths)

                    if ($SelectedFolders.Count -gt 0) {
                        return $SelectedFolders
                    }

                    Write-Host "[INFO] No folders selected." -ForegroundColor Yellow
                    Start-Sleep -Seconds 1

                }

                # --------------------------------------------
                # COMBINE DRIVES + FOLDERS
                # --------------------------------------------

                "4" {

                    Write-Host ""
                    Write-Host "[1/2] SELECT DRIVES" -ForegroundColor Cyan

                    $SelectedDrives = Select-FVItems `
                        -Items $Drives `
                        -Prompt "Select-Drives> "

                    if (-not $SelectedDrives) {
                        continue
                    }

                    Write-Host ""
                    Write-Host "[2/2] ADD FOLDER PATHS" -ForegroundColor Cyan

                    $SelectedFolders = @(Read-FVFolderPaths)

                    $Combined = @(
                        $SelectedDrives
                        $SelectedFolders
                    ) | Select-Object -Unique

                    return $Combined

                }

                # --------------------------------------------
                # QUIT
                # --------------------------------------------

                "Q" {
                    return
                }

                default {

                    Write-Host "[INVALID] Select 1, 2, 3, 4 or Q." -ForegroundColor Red
                    Start-Sleep -Seconds 1

                }

            }

        }

    }


# ============================================================
# EXTENSION FILTER
# ============================================================

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " FILEVACUUM :: EXTENSION FILTER" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Input .extensions to fetch your target file from:" -ForegroundColor White
Write-Host "[DEMO] pdf,lua,c,cpp,py,java" -ForegroundColor DarkGray
Write-Host ""

$ExtensionInput = Read-Host "Extensions"

# Normalize and validate extensions
$SelectedExtensions = @()

if (-not [string]::IsNullOrWhiteSpace($ExtensionInput)) {

    $SelectedExtensions = @(
        $ExtensionInput -split ',' |
        ForEach-Object {
            $Extension = $_.Trim().TrimStart('.').ToLowerInvariant()

            if ($Extension -match '^[a-z0-9][a-z0-9_-]*$') {
                $Extension
            }
            elseif (-not [string]::IsNullOrWhiteSpace($Extension)) {
                Write-Host "[SKIPPED] Invalid extension: $_" -ForegroundColor Yellow
            }
        } |
        Sort-Object -Unique
    )

    if ($SelectedExtensions.Count -eq 0) {
        Write-Host "[WARNING] No valid extensions entered." -ForegroundColor Yellow
        Write-Host "[INFO] Falling back to all file types." -ForegroundColor Yellow
    }
}

if ($SelectedExtensions.Count -gt 0) {
    Write-Host ""
    Write-Host "[INFO] $($SelectedExtensions.Count) extensions selected:" -ForegroundColor Green
    Write-Host ($SelectedExtensions -join ", ") -ForegroundColor Cyan
}
else {
    Write-Host ""
    Write-Host "[INFO] All file types enabled." -ForegroundColor Green
}

Write-Host ""


    # --------------------------------------------------------
    # 6. MAIN SEARCH LOOP
    # --------------------------------------------------------

    while ($true) {

        # Scope MUST be selected before searching.

        $SearchRoots = @(Select-FVScope)

        if ($SearchRoots.Count -eq 0) {
            Clear-Host
            Write-Host "[INFO] FileVacuum closed." -ForegroundColor Yellow
            return
        }

        # Validate and normalize every root.

        $SearchRoots = @(
            $SearchRoots |
            Where-Object {
                $_ -and (Test-Path -LiteralPath $_ -PathType Container)
            } |
            ForEach-Object {
                (Get-Item -LiteralPath $_).FullName
            } |
            Select-Object -Unique
        )

        if ($SearchRoots.Count -eq 0) {
            Write-Host "[ERROR] No valid search roots." -ForegroundColor Red
            Start-Sleep -Seconds 2
            continue
        }

        # ----------------------------------------------------
        # 7. DISPLAY SELECTED SEARCH SCOPE
        # ----------------------------------------------------

        Clear-Host

        Write-Host ""
        Write-Host "================================================" -ForegroundColor Cyan
        Write-Host "              CONFIRMED SEARCH SCOPE" -ForegroundColor Cyan
        Write-Host "================================================" -ForegroundColor Cyan

        foreach ($Root in $SearchRoots) {
            Write-Host "  + $Root" -ForegroundColor Green
        }

        Write-Host ""
        Write-Host "TOTAL SEARCH ROOTS: $($SearchRoots.Count)" -ForegroundColor Yellow

        # ----------------------------------------------------
        # 8. GET SEARCH QUERY
        # ----------------------------------------------------

        if ([string]::IsNullOrWhiteSpace($Query)) {

            Write-Host ""

            $Query = Read-Host "Enter filename or search term"

        }

        if ([string]::IsNullOrWhiteSpace($Query)) {

            Write-Host "[CANCELLED] Empty search query." -ForegroundColor Yellow

            $Query = $null
            continue

        }

        # ----------------------------------------------------
        # 9. STRICT PER-ROOT FD SCANNING
        # ----------------------------------------------------
        #
        # IMPORTANT:
        # fd is invoked separately for EACH selected root.
        #
        # No implicit current-directory fallback.
        # No unselected drive is passed to fd.
        # No unrestricted fd invocation.
        #
        # This is the critical scope-isolation fix.
        # ----------------------------------------------------

        $AllFiles = [System.Collections.Generic.List[string]]::new()

        Clear-Host

        Write-Host ""
        Write-Host "================================================" -ForegroundColor Cyan
        Write-Host "              FILE VACUUM SCANNER" -ForegroundColor Cyan
        Write-Host "================================================" -ForegroundColor Cyan

        Write-Host ""
        Write-Host "QUERY: $Query" -ForegroundColor Yellow

        Write-Host ""
        Write-Host "SCANNING ONLY THESE LOCATIONS:" -ForegroundColor Cyan

        foreach ($Root in $SearchRoots) {

            Write-Host ""
            Write-Host "[SCAN] $Root" -ForegroundColor Green

            # Verify that the selected root still exists.

            if (-not (Test-Path -LiteralPath $Root -PathType Container)) {

                Write-Host "[SKIPPED] Root unavailable." -ForegroundColor Yellow
                continue

            }

            # One explicit root per fd process.

            
$FdArguments = @(
    "--hidden"
    "--no-ignore"
    "--type"
    "f"
    "--absolute-path"
    "--color"
    "never"
)

# Apply extension filtering directly during fd scanning
if ($SelectedExtensions.Count -gt 0) {

    foreach ($Extension in $SelectedExtensions) {
        $FdArguments += @(
            "--extension"
            $Extension
        )
    }
}

# Search pattern and selected root
$FdArguments += @(
    "."
    $Root
)

$RootFiles = @(& $FD.Source @FdArguments 2>$null)


            try {

                $RootFiles = @(
                    & $FD.Source @FdArguments 2>$null
                )

                foreach ($File in $RootFiles) {

                    if (-not [string]::IsNullOrWhiteSpace($File)) {
                        $AllFiles.Add([string]$File)
                    }

                }

                Write-Host "[DONE] $($RootFiles.Count) files discovered." -ForegroundColor DarkGreen

            }
            catch {

                Write-Host "[ERROR] $Root : $($_.Exception.Message)" -ForegroundColor Red

            }

        }

        # ----------------------------------------------------
        # 10. PREPARE RESULTS
        # ----------------------------------------------------

        if ($AllFiles.Count -eq 0) {

            Write-Host ""
            Write-Host "[INFO] No files discovered in the selected locations." -ForegroundColor Yellow

            $Again = Read-Host "Try another search? (Y/N)"

            if ($Again -match '^(Y|YES)$') {
                $Query = $null
                continue
            }

            return

        }

        Write-Host ""
        Write-Host "[OK] Total files discovered: $($AllFiles.Count)" -ForegroundColor Green

        Write-Host "[SEARCH] Opening fzf..." -ForegroundColor Cyan

        Start-Sleep -Milliseconds 500

        # ----------------------------------------------------
        # 11. FZF INTERACTIVE SEARCH
        # ----------------------------------------------------

        $FzfArguments = @(
            "--height=90%"
            "--layout=reverse"
            "--border"
            "--info=inline"
            "--no-multi"
            "--prompt=FileVacuum> "
            "--header=ENTER: Select | CTRL+C: Cancel | Type to filter"
            "--query=$Query"
        )

        
# ============================================================
# COLOR-CODED FZF FILE SELECTION
# ============================================================

$ESC = [char]27

# ANSI colors
$DirectoryColor = "$ESC[38;5;45m"   # Cyan
$FileColor      = "$ESC[38;5;220m"  # Yellow
$ResetColor     = "$ESC[0m"

# Build colored display entries
$DisplayFiles = foreach ($FilePath in $AllFiles) {

    $Directory = [System.IO.Path]::GetDirectoryName($FilePath)
    $FileName  = [System.IO.Path]::GetFileName($FilePath)

    "$DirectoryColor$Directory$ResetColor$FileColor\$FileName$ResetColor"
}

# Run fzf with colored entries
$SelectedLine = @(
    $DisplayFiles | & $FZF.Source @FzfArguments --ansi
) | Select-Object -First 1

# Restore the original, uncolored full path
if (-not [string]::IsNullOrWhiteSpace([string]$SelectedLine)) {

    $SelectedPath = [regex]::Replace(
        [string]$SelectedLine,
        '\x1B\[[0-9;]*m',
        ''
    )

}
else {
    $SelectedPath = $null
}

# Validate selection
if (
    [string]::IsNullOrWhiteSpace([string]$SelectedPath) -or
    -not (Test-Path -LiteralPath $SelectedPath -PathType Leaf)
) {

    Write-Host ""
    Write-Host "[INFO] No file selected." -ForegroundColor Yellow

    $Again = Read-Host "Search again? (Y/N)"

    if ($Again -match '^(Y|YES)$') {
        $Query = $null
        continue
    }

    return

}


        $SelectedPath = (Get-Item -LiteralPath $SelectedPath).FullName

        # ----------------------------------------------------
        # 12. FILE ACTION MENU
        # ----------------------------------------------------

        while ($true) {

            if (-not (Test-Path -LiteralPath $SelectedPath -PathType Leaf)) {

                Write-Host "[ERROR] File no longer exists." -ForegroundColor Red
                break

            }

            $FileInfo = Get-Item -LiteralPath $SelectedPath

            Clear-Host

            Write-Host ""
            Write-Host "================================================" -ForegroundColor Cyan
            Write-Host "                 FILE VACUUM" -ForegroundColor Cyan
            Write-Host "================================================" -ForegroundColor Cyan

            Write-Host ""
            Write-Host "SELECTED FILE:" -ForegroundColor Yellow

            Write-Host $SelectedPath -ForegroundColor Green

            Write-Host ""
            Write-Host "FILE INFORMATION:" -ForegroundColor Yellow

            Write-Host "Name      : $($FileInfo.Name)"
            Write-Host "Extension : $($FileInfo.Extension)"
            Write-Host "Size      : $([math]::Round($FileInfo.Length / 1KB, 2)) KB"
            Write-Host "Directory : $($FileInfo.DirectoryName)"
            Write-Host "Modified  : $($FileInfo.LastWriteTime)"

            Write-Host ""
            Write-Host " [1] Copy full file path"
            Write-Host " [2] Open file"
            Write-Host " [3] Copy actual file (CTRL+V)"
            Write-Host " [4] Copy file to another folder"
            Write-Host " [5] Move file to another folder"
            Write-Host " [6] Reveal in File Explorer"
            Write-Host " [7] Open terminal in file location"
            Write-Host " [8] File properties"
            Write-Host " [9] Delete file"
            Write-Host ""
            Write-Host " [R] Search again"
            Write-Host " [Q] Quit"
            Write-Host ""

            $Action = Read-Host "Select an action"

            switch ($Action.ToUpperInvariant()) {

                # --------------------------------------------
                # COPY FULL PATH
                # --------------------------------------------

                "1" {

                    Set-Clipboard -Value $SelectedPath

                    Write-Host "[OK] Full path copied." -ForegroundColor Green

                    Read-Host "Press ENTER to continue"
                }

                # --------------------------------------------
                # OPEN FILE
                # --------------------------------------------

                "2" {

                    Start-Process -FilePath $SelectedPath
                }

                # --------------------------------------------
                # COPY ACTUAL FILE
                # --------------------------------------------

                "3" {

                    try {

                        Set-Clipboard -Path $SelectedPath -ErrorAction Stop

                        Write-Host "[OK] Actual file copied." -ForegroundColor Green
                        Write-Host "Use CTRL+V to paste." -ForegroundColor Cyan

                    }
                    catch {

                        Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red

                    }

                    Read-Host "Press ENTER to continue"
                }

                # --------------------------------------------
                # COPY FILE
                # --------------------------------------------

                "4" {

                    $Destination = Read-Host "Destination folder"

                    if (Test-Path -LiteralPath $Destination -PathType Container) {

                        try {

                            Copy-Item -LiteralPath $SelectedPath -Destination $Destination -ErrorAction Stop

                            Write-Host "[OK] File copied." -ForegroundColor Green

                        }
                        catch {

                            Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red

                        }

                    }
                    else {

                        Write-Host "[ERROR] Invalid destination." -ForegroundColor Red

                    }

                    Read-Host "Press ENTER to continue"
                }

                # --------------------------------------------
                # MOVE FILE
                # --------------------------------------------

                "5" {

                    $Destination = Read-Host "Destination folder"

                    if (Test-Path -LiteralPath $Destination -PathType Container) {

                        try {

                            Move-Item -LiteralPath $SelectedPath -Destination $Destination -ErrorAction Stop

                            Write-Host "[OK] File moved." -ForegroundColor Green

                            return

                        }
                        catch {

                            Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red

                        }

                    }
                    else {

                        Write-Host "[ERROR] Invalid destination." -ForegroundColor Red

                    }

                    Read-Host "Press ENTER to continue"
                }

                # --------------------------------------------
                # REVEAL IN EXPLORER
                # --------------------------------------------

                "6" {

                    Start-Process explorer.exe -ArgumentList "/select,`"$SelectedPath`""

                }

                # --------------------------------------------
                # OPEN TERMINAL
                # --------------------------------------------

                "7" {

                    if (Get-Command wt.exe -ErrorAction SilentlyContinue) {

                        Start-Process wt.exe -ArgumentList @(
                            "-d"
                            $FileInfo.DirectoryName
                        )

                    }
                    else {

                        Start-Process powershell.exe -WorkingDirectory $FileInfo.DirectoryName

                    }

                }

                # --------------------------------------------
                # FILE PROPERTIES
                # --------------------------------------------

                "8" {

                    try {

                        $Shell = New-Object -ComObject Shell.Application

                        $Folder = $Shell.Namespace($FileInfo.DirectoryName)
                        $Item = $Folder.ParseName($FileInfo.Name)

                        if ($Item) {
                            $Item.InvokeVerb("properties")
                        }

                    }
                    catch {

                        Write-Host "[ERROR] Unable to open properties." -ForegroundColor Red

                    }

                    Read-Host "Press ENTER to continue"
                }

                # --------------------------------------------
                # DELETE FILE
                # --------------------------------------------

                "9" {

                    Write-Host ""
                    Write-Host "[WARNING] Permanent deletion requested." -ForegroundColor Red

                    $Confirm = Read-Host "Type DELETE to confirm"

                    if ($Confirm -ceq "DELETE") {

                        try {

                            Remove-Item -LiteralPath $SelectedPath -Force -ErrorAction Stop

                            Write-Host "[OK] File deleted." -ForegroundColor Green

                            return

                        }
                        catch {

                            Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red

                        }

                    }
                    else {

                        Write-Host "[INFO] Deletion cancelled." -ForegroundColor Yellow

                    }

                    Read-Host "Press ENTER to continue"
                }

                # --------------------------------------------
                # SEARCH AGAIN
                # --------------------------------------------

                "R" {

                    $Query = $null
                    break

                }

                # --------------------------------------------
                # QUIT
                # --------------------------------------------

                "Q" {

                    Clear-Host
                    return

                }

                default {

                    Write-Host "[INVALID] Select a valid option." -ForegroundColor Red

                    Start-Sleep -Seconds 1

                }

            }

            if ($Action -match '^[Rr]$') {
                break
            }

        }

    }

}


# ============================================================
# END OF FILE VACUUM v2.2
# ============================================================
